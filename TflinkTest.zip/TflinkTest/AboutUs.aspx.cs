﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;

namespace TflinkTest
{
    public partial class AboutUs : System.Web.UI.Page
    {
        SqlCommand cm = null;
        SqlDataAdapter da = null;
        DataSet ds = null;
        string Query = null;
        DataTable dt;
        string employeeid = "";
        string userid = "";

        Secureconnection connect = new Secureconnection();
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                getdata();
            }
        }
        public void getdata()
        {
            //Get data show in textbox
            try
            {
                SqlConnection con = connect.GetEMployeeconnnect();
                SqlCommand cmd = null;
                cmd = new SqlCommand("SPselectAbout", con);
                cmd.CommandType = System.Data.CommandType.StoredProcedure;
                con.Open();
                SqlDataReader reader = cmd.ExecuteReader();

                List<Test> TestList = new List<Test>();
                Test test = null;

                if (reader.HasRows)
                {
                    reader.Read();
                    content.InnerHtml = Convert.ToString(reader["Desccription"]);
                }

            }
            catch
            {
            }

        }
    }
}