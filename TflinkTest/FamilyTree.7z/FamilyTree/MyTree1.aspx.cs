﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;
using System.IO;
using System.Net.Mail;
using System.Globalization;

namespace TflinkTest.FamilyTree
{
    public partial class MyTree1 : System.Web.UI.Page
    {
        SqlCommand cmd = null;
        SqlDataAdapter da = null;
        DataSet ds = null;
        string Query = null;
        DataTable dt;
        string Fnamess = "";
        string employeeid = "";
        string userid = "";
        string memid = "";
        string memberidbysub = "";

        Secureconnection connect = new Secureconnection();
        protected void Page_Load(object sender, EventArgs e)
        {
            memid = Request.QueryString["Memid"];
            try
            {
                userid = Session["UserId"].ToString();
                Fnamess = Session["FirstName"].ToString();
            }
            catch
            {
                Response.Redirect("~/Home.aspx");
            }

            if (!IsPostBack)
            {
                if (Fnamess != "")
                {
                    scriptid.InnerHtml = "<script>setTimeout(function () {$('#myModal').modal();}, 1000);</script>";
                }
                else
                {
                    scriptid.InnerHtml = "";
                }

            }
            //try
            //{
            if (checkmemberid() == "Available")
            {
                BindTree(userid);
            }
            else
            {
                scriptid.InnerHtml = "<script>setTimeout(function () {$('#myModal').modal();}, 1000);</script>";
            }
            //}
            //catch
            //{ 

            //}




        }
        protected void btn_save_Click(object sender, EventArgs e)
        {
            Submitdata();
            scriptid.InnerHtml = "";
        }

        protected void btn_Edit_Click(object sender, EventArgs e)
        {
            txt_Dod.Visible = true;
            chb_dodCirca.Visible = true;
            btn_Edit.Visible = false;
            divcreca.Visible = true;
        }
        public void Submitdata()
        {
            SqlConnection con = connect.GetEMployeeconnnect();
            string Fid = Getfamilyid();
            string Memid = GetMemberid();
            string Userid = "";
            string Password = "";
            string dob = "";
            string dod = "";
            if (txt_Dob.Text != "")
            {
                dob = txt_Dob.Text.Trim();
                DateTime date1 = Convert.ToDateTime(dob.ToString());
                dob = date1.ToString("yyyy/MM/dd");
                ////DateTime Fdate = DateTime.ParseExact(txt_Dob.Text.ToString(), "yyyy/MM/dd", CultureInfo.InvariantCulture); 

                ////Fdate = Convert.ToDateTime(Fdate.Date.ToString("yyyy/MM/dd"));
                ////dob = Fdate.Date.ToString("yyyy/MM/dd");
            }
            else
            {
                dob= DateTime.Now.ToString("yyyy/MM/dd");
            }
            if (txt_Dod.Text != "")
            {
                dod = txt_Dod.Text.Trim();
                DateTime date2 = Convert.ToDateTime(dod.ToString());
                dod = date2.ToString("yyyy/MM/dd");
            }
            else
            {
                dod = DateTime.Now.ToString("yyyy/MM/dd");
            }

            try
            {
                if (Session["UserId"] != null && Session["Password"] != null)
                {
                    Userid = Session["UserId"].ToString();
                    Password = Session["Password"].ToString();
                }
            }
            catch
            {

            }
            string creradod = "";
            string creradob = "";
            if (chb_dobCirca.Checked == true)
            {
                creradob = "yes";
            }
            if (chb_dodCirca.Checked == true)
            {
                creradod = "yes";
            }
            string date = DateTime.Now.ToString("yyyy/MM/dd");
            string time = DateTime.Now.ToString("hh:mm:ss");
            cmd = new SqlCommand("SPMainMembers", con);
            cmd.CommandType = CommandType.StoredProcedure;
            //cmd.Parameters.Add("@id", SqlDbType.Int).Value = txtRegdId.Text;
            cmd.Parameters.AddWithValue("id", Userid);
            cmd.Parameters.AddWithValue("FamilyId", Fid);
            cmd.Parameters.AddWithValue("MemberId", Memid);
            cmd.Parameters.AddWithValue("FirstName", txt_Fname.Text.Trim());
            cmd.Parameters.AddWithValue("LastName", txt_Lname.Text.Trim());
            cmd.Parameters.AddWithValue("Contact", txt_Phonenmb.Text.Trim());
            cmd.Parameters.AddWithValue("Gender", ddl_gender.Text.Trim());
            cmd.Parameters.AddWithValue("EmailId", txt_Email.Text.Trim());
            cmd.Parameters.AddWithValue("Address", txt_address.Text.Trim());
            cmd.Parameters.AddWithValue("City", txt_City.Text.Trim());
            cmd.Parameters.AddWithValue("State", txt_State.Text.Trim());
            cmd.Parameters.AddWithValue("Dob", txt_Dob.Text.Trim());
            cmd.Parameters.AddWithValue("Creradob", creradob);
            cmd.Parameters.AddWithValue("Country", ddl_Country.Text.Trim());
            cmd.Parameters.AddWithValue("Birthloc", txt_Birthloc.Text.Trim());
            cmd.Parameters.AddWithValue("Dod", txt_Dod.Text.Trim());
            cmd.Parameters.AddWithValue("Creradod", creradod);
            cmd.Parameters.AddWithValue("Notes", txt_notes.Text.Trim());
            cmd.Parameters.AddWithValue("Userid", Userid.ToString());
            cmd.Parameters.AddWithValue("Password", Password.ToString());
            cmd.Parameters.AddWithValue("Enterby", "Admin");
            cmd.Parameters.AddWithValue("Enterdate", date);
            cmd.Parameters.AddWithValue("Entertime", time);

            if (btn_save.Text == "Update")
            {
                cmd.Parameters.AddWithValue("StatementType", "Update");
            }
            else if (btn_save.Text == "Save")
            {
                cmd.Parameters.AddWithValue("StatementType", "Update");
            }
            con.Open();
            int k = cmd.ExecuteNonQuery();
            if (k != 0)
            {
                BindTree(userid);
               // Response.Write("<script>alert('Data Saved Successfully.')</script>");
                Session["Slno"] = null;
                //   Response.Redirect("../ERPApp/ViewAdmission.aspx");
            }

            con.Close();
        }
        public string Getfamilyid()
        {
            SqlConnection con = connect.GetEMployeeconnnect();
            string id = "";
            if (con.State == ConnectionState.Closed)
            {
                con.Open();
            }
            try
            {
                string Query = "select * from MainMembers where FamilyId LIKE 'Family00%' ";
                DataTable dt = RetriveData(Query);
                if (dt.Rows.Count > 0)
                {
                    id = "Family00" + dt.Rows.Count + 1;
                }
                else
                {
                    id = "Family00" + 1;
                }

            }
            catch
            {

            }
            finally
            {
                if (con.State == ConnectionState.Open)
                {
                    con.Close();
                }
            }
            return id;
        }
        public DataTable RetriveData(string Query)
        {
            SqlConnection con = connect.GetEMployeeconnnect();
            DataTable dt = new DataTable();
            try
            {

                da = new SqlDataAdapter(Query, con);

                da.Fill(dt);
                return dt;
            }
            catch
            {
                return dt;
            }
        }
        public string GetMemberid()
        {
            SqlConnection con = connect.GetEMployeeconnnect();
            string id = "";
            if (con.State == ConnectionState.Closed)
            {
                con.Open();
            }
            try
            {
                string Query = "select * from MainMembers where MemberId LIKE 'Memberid%' ";
                DataTable dt = RetriveData(Query);
                if (dt.Rows.Count > 0)
                {
                    id = "Memberid" + dt.Rows.Count + 1;
                }
                else
                {
                    id = "Memberid" + 1;
                }

            }
            catch
            {

            }
            finally
            {
                if (con.State == ConnectionState.Open)
                {
                    con.Close();
                }
            }
            return id;
        }
        public void BindTree(string userid)
        {
            string MemberId = "";
            SqlConnection con = connect.GetEMployeeconnnect();
            SqlDataAdapter da = new SqlDataAdapter("select * from MainMembers where Userid='" + userid + "'", con);
            DataTable dt = new DataTable();
            da.Fill(dt);
            if (dt.Rows.Count > 0)
            {
                MemberId = dt.Rows[0]["MemberId"].ToString();
                Session["Memberid"] = MemberId.ToString();
            }
            try
            {
                if (memid.ToString() != "")
                {
                    Session["Memberid"] = memid;
                    MemberId = Session["Memberid"].ToString();
                }
            }
            catch
            {

            }


            string Fname = "";
            string Lname = "";
            string Location = "";
            string Email = "";
            string dob = "";
            string Gender = "";
            int cn = 0;
            SqlDataAdapter da1 = new SqlDataAdapter("select * from MainMembers where MemberId='" + MemberId + "'", con);
            DataTable dt1 = new DataTable();
            da1.Fill(dt1);
            if (dt1.Rows.Count > 0)
            {
                Fname = dt1.Rows[0]["FirstName"].ToString();
                Lname = dt1.Rows[0]["LastName"].ToString();
                dob = dt1.Rows[0]["Dob"].ToString();
                Gender = dt1.Rows[0]["Gender"].ToString();
                Email = dt1.Rows[0]["EmailId"].ToString();
                Location = dt1.Rows[0]["City"].ToString();
                MailName.InnerText = Fname + " " + Lname;
                PLocation.InnerText = Location;
                string yr = DateTime.Now.ToString("yyyy");
                string yr1 = Convert.ToDateTime(dob).ToString("yyyy");
                int age = Convert.ToInt32(yr) - Convert.ToInt32(yr1);
                if (Gender == "Male")
                {
                    Gender = "M";
                }
                else
                {
                    Gender = "F";
                }
                Years.InnerText = Gender + " - " + age + " " + "Years";
            }
            Getspouse();
        }

        public void Getspouse()
        {
            string bindspouse = "";
            string MemberId = "";
            try
            {
                MemberId = Session["Memberid"].ToString();
            }
            catch
            {

            }

            string MemberFname = "";
            string SpouseFName = "";
            string MemberLname = "";
            string SpouseLName = "";
            string dob = "";
            string spomemberid = "";
            string Gender = "";
            SqlConnection con = connect.GetEMployeeconnnect();
            SqlDataAdapter da1 = new SqlDataAdapter("select * from Tbl_SpouseOf where Spouseofid='" + MemberId + "'", con);

            DataTable dt1 = new DataTable();
            da1.Fill(dt1);
            if (dt1.Rows.Count > 0)
            {
                for (int i = 0; i < dt1.Rows.Count; i++)
                {

                    MemberFname = dt1.Rows[i]["MemberFName"].ToString();
                    SpouseFName = dt1.Rows[i]["SpouseoffName"].ToString();
                    MemberLname = dt1.Rows[i]["MemberLName"].ToString();
                    SpouseLName = dt1.Rows[i]["SpouseofLName"].ToString();
                    spomemberid = dt1.Rows[i]["Memberid"].ToString();
                    Gender = dt1.Rows[i]["Gender"].ToString();
                    dob = dt1.Rows[i]["Dob"].ToString();
                    string yr = DateTime.Now.ToString("yyyy");
                    string yr1 = Convert.ToDateTime(dob).ToString("yyyy");
                    int age = Convert.ToInt32(yr) - Convert.ToInt32(yr1);
                    if (Gender == "Male")
                    {
                        Gender = "M";
                    }
                    else
                    {
                        Gender = "F";
                    }

                    bindspouse += "   <li runat='server'><div class='box-main-tree'><span class='box-tree-left'><a href='#'>" + MemberFname + "   " + MemberLname + "</a>";
                    bindspouse += "<p>Montreal CA</p> <p>" + Gender + " - " + age + " years</p>  </span>";
                    bindspouse += " <span class='box-tree-right'><a href='MyTree1.aspx?Memid=" + spomemberid + "'> <img src='images/tree2.jpg' width='30' height='30' /></a> ";
                    bindspouse += "<a href='#'> <img src='images/greenimg2.jpg' width='30' height='30' /></a>";
                    bindspouse += "<a href='#'><img src='images/image4.png' width='30' height='30' /></a> </span></div></li>";
                }
                Bind_Spouse.InnerHtml = bindspouse.ToString();


            }
        }
        public string checkmemberid()
        {
            SqlConnection con = connect.GetEMployeeconnnect();
            SqlDataAdapter da1 = new SqlDataAdapter("select * from MainMembers where Userid='" + userid + "'", con);
            DataTable dt1 = new DataTable();
            da1.Fill(dt1);
            string Status = "";
            if (dt1.Rows.Count > 0)
            {
                Status = dt1.Rows[0]["MemberId"].ToString();
                txt_Email.Text = dt1.Rows[0]["EmailId"].ToString();
            }
            if (Status != "")
            {
                Status = "Available";
            }
            else
            {
                Status = "Not Available";
            }
            return Status;
        }
    }
}